/*
 Example for reading a file byte-by-byte.
 In this case, it reads its own code.
 @author: Thomas Lehmann
 @date: 2018-05-15
*/
#include <stdio.h>

int main(void){
	FILE *input = NULL;
	
	input = fopen("cat.c", "r");
	
	if( NULL != input ){
		char character = ' ';
		int elements = 0;
		while( !feof(input) ){
			character = (char)fgetc(input);
			printf("%c", character);
		}
		fclose(input);
	}
	 
	return 0;
}