#include <stdio.h>
#include "ti_expectations.h"

int main(void){
	EXPECT_TRUE(6==CalculateTestnumber(25555,7);
	EXPECT_TRUE(4==1);
	return 0;
}