#include <stdio.h>
#include "ti_expectations.h"
int main(void){
	
	return 0;
}