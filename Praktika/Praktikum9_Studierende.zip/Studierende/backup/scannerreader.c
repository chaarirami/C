/* 
Assignment 9
Start code for problem.

Add and change code at appropriete places!

@authors: Thomas Lehmann
@date: 2018-05-24
@cooperation: -
*/

#include <stdio.h>
#include <stdlib.h>

int main(void){
	FILE *input = NULL;
	input = fopen("ls_single_line_short.txt","r");
	double angle_min = 0.0;
	double angle_inc = 0.0;
	
// Add Code here

	if(NULL != input){
		if(!feof(input)){

// Add Code here

		}
		fclose(input);
	}

	if(success){
		FILE *output = NULL;
		output = fopen("ls_data.csv","w");
		if( NULL!=output ){

// Add Code here


		}
	}	

// Add Code here
	
	return 0;
}